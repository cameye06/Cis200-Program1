﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryMovie
// section 1
// This creates LibraryMovie class that is derived from LibraryMediaItem

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class LibraryMovie : LibraryMediaItem
    {

        public enum MPAARatings {G, PG, PG13, R, NC17, U}; // MPAA reatings for use in Rating
        public string _director; // director of movie
        public MediaType _medium; // type of media being checked out
        public MPAARatings _rating; // audiance ratings for movie

        // inherites theTitle, thePublisher, theCopyrightYear, theCallNumber, theLoanPeriod, theDuration, theMedium
        // has new property: Director and Rating
        public LibraryMovie
            (
          String theTitle,
          String thePublisher,
          int theCopyrightYear,
          String theCallNumber,
          double theDuration,
          int theLoanPeriod,
          String theDirector,
          MediaType theMedium,
          MPAARatings theRating
           ) : base
                (theTitle,
                thePublisher,
                theCopyrightYear, 
                theCallNumber,
                theLoanPeriod,
                theDuration,
                theMedium)
        {
            Director = theDirector;
            Medium = theMedium;
            Rating = theRating;


        }

        public string Director
        {
            // Precondition:  None
            // Postcondition: The Director has been returned
            get
            {
                return _director;
            }

            // Precondition:  none
            // Postcondition: The Director has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Director)}", value,
                        $"{nameof(Director)} must not be null or empty");
                else
                    _director = value;
            }
        }




        // Precondition:  a number of days has been entered
        // Postcondition: a calculated fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal rate; //ammount of money/day
            decimal dvdvhs = (decimal)1.00;
            decimal bluray = (decimal)1.50;
            // $1.00/day late for DVD and VHS media, and $1.50/day late
            // for BluRay media (both with a $25.00 limit)
            if (_medium == MediaType.DVD || _medium == MediaType.VHS) 
            {rate = dvdvhs;} //if dvd or vhs
            else { rate = bluray;} //if bluray

            decimal fee = days * rate; // how much they will have to pay

            if (fee > (decimal)25.00) // if late fee is more that $25 it returns 25$
            { fee = (decimal)25.00;}

            return fee; // return fee
        }

        public MPAARatings Rating
        {
            // Precondition:  None
            // Postcondition: The rating has been set to the specified value that is not VHS, DVD, or BluRAy
            get { return _rating; }
            // Precondition:  None
            // Postcondition: The rating has been returned
            set { _rating = value; }

        }



        public override MediaType Medium
        {
            // Precondition:  None
            // Postcondition: The medium has been set to the specified 
            get { return _medium; }
            // Precondition:  value that is not CD, SADC, or Vinyl
            // Postcondition: The medium has been returned
            set
            {

                if (value == MediaType.CD || value == MediaType.SACD || value == MediaType.VINYL) // checks to see it CD, SADC, or Vinyl
                    throw new ArgumentOutOfRangeException($"{nameof(Medium)}", value,
                        $"{nameof(Medium)} of a movie has to be a VHS, DVD, or BluRay");

                _medium = value;
            } 
            
        }

        public override string ToString() // sends information formated as a string
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";
            return $"Title: {Title}{NL}" + $"Director: {Director}{NL}" + $"Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}" + $"Call Number: {CallNumber}{NL}" + $"Loan Period: {LoanPeriod}{NL}"
                + $"Rating: {Rating}{NL}" + $"Media type: {Medium}{NL}" + $"Duraton {Duration}{NL}" + checkedOutBy + $"{ NL}";

        }



    }
}

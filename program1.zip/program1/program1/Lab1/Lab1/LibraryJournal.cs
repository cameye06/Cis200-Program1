﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryJournal
// section 1
// This creates LibraryJournal class that is derived from Library Periodical

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class LibraryJournal : LibraryPeriodical
    {

        public string _discipline; // the discipline of the journal
        public string _editor; // hte journal's editor

        // inherites theTitle, thePublisher, theCopyrightYear, CallNumber, loan period, volume, and number 
        // has new property: disciplie and editor
        public LibraryJournal
          (String theTitle, String thePublisher,
        int theCopyrightYear, int theLoanPeriod, 
        String theCallNumber, int theVolume, 
        int theNumber, String theDiscipline, String theEditor)
          : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {
            Discipline = theDiscipline;
            Editor = theEditor;
        }

        public string Discipline
        {
            // Precondition:  None
            // Postcondition: The Discipline has been returned
            get
            {
                return _discipline;
            }

            // Precondition:  none
            // Postcondition: The Discipline has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Discipline)}", value,
                        $"{nameof(Discipline)} must not be null or empty");
                else
                    _discipline = value;
            }
        }

        public string Editor
        {
            // Precondition:  None
            // Postcondition: The editor has been returned
            get
            {
                return _editor;
            }

            // Precondition:  none
            // Postcondition: The editor has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Editor)}", value,
                        $"{nameof(Editor)} must not be null or empty");
                else
                    _editor = value;
            }
        }

        public override string ToString() // returns information formated as a string
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";
            return $"Title: {Title}{NL}" + $"Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}" + $"Call Number: {CallNumber}{NL}" + $"Loan Period: {LoanPeriod}{NL}"
                + $"Volume: {Volume}{NL}" + $"Number: {Number}{NL}" + $"Editor: {Editor}{NL}" + $"Discipline: {Discipline}{NL}" 
                + checkedOutBy + $"{ NL}";

        }



        // Precondition:  a number of days has been entered
        // Postcondition: a calculated fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal rate = (decimal).75; // the cost per day
            decimal fee = days * rate;
            return fee;
        }


    }
}

﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryMagazine
// section 1
// This creates LibraryMagazine class that is derived from LibraryPeriodical

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class LibraryMagazine : LibraryPeriodical
    {

        public LibraryMagazine
          (String theTitle, String thePublisher,
        int theCopyrightYear, int theLoanPeriod,
        String theCallNumber, int theVolume,
        int theNumber)
          : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {}

        public override string ToString() // returns information formated as a string
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";
            return $"Title: {Title}{NL}" + $"Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}" + $"Call Number: {CallNumber}{NL}" + $"Loan Period: {LoanPeriod}{NL}"
                + $"Volume: {Volume}{NL}" + $"Number: {Number}{NL}" + checkedOutBy + $"{ NL}";

        }



        // Precondition:  a number of days has been entered
        // Postcondition: a calculated fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal rate = (decimal).25; // the cost per day
            decimal fee = days * rate;

            if (fee > (decimal)20.00) //sets limit of $20.00 to fee
            { fee = (decimal)20.00; }

            return fee;
        }




    }
}

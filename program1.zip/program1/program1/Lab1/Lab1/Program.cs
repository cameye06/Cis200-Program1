﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: Program
// section 1
// This file tests the classes of the library heiarchy



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-----------------------------LibraryBook test-------------------------------");
            LibraryBook book1 = new LibraryBook("book","author","publisher",1999, "111", 3);
            Console.WriteLine(book1.ToString());
            Console.WriteLine($"late fee is : "+book1.CalcLateFee(100));

            LibraryPatron pat1 = new LibraryPatron("Gary Oak", "ab123");
            book1.CheckOut(pat1);

            Console.WriteLine(book1.ToString());
         

            Console.WriteLine("-----------------------------LibraryMovie test-------------------------------");
            LibraryMovie movie1 = new LibraryMovie("title ", "  publisher", 1999, "123ac", 93.4, 5, "bob john", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG13);
            Console.WriteLine(movie1.ToString());

            Console.WriteLine("-----------------------------LibraryMusic test-------------------------------");
            LibraryMusic music1 = new LibraryMusic("Song", "Publisher", 1924, 34, "aasf123", 17.83, "The Strokes", LibraryMediaItem.MediaType.CD, 12);
            music1.CheckOut(pat1);
            Console.WriteLine(music1.ToString());
            Console.WriteLine(music1.CalcLateFee(100));

            Console.WriteLine("-----------------------------LibraryJournal test-------------------------------");
            LibraryJournal jou1 = new LibraryJournal("Title", "publisher journal", 1242, 234, "af235df", 2, 12, "biology", "glen garry");
            Console.WriteLine(jou1.ToString());
            Console.WriteLine(jou1.CalcLateFee(1000));
            jou1.CheckOut(pat1);
            Console.WriteLine(jou1.ToString());

            Console.WriteLine("-----------------------------LibraryMagazine test-------------------------------");
            LibraryMagazine mag1 = new LibraryMagazine("title", "publisher mag", 2523, 34, "adsf3esfd", 12, 234);
            Console.WriteLine(mag1.ToString());
            Console.WriteLine(mag1.CalcLateFee(430));
           


        }
    }
}

﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryMediaItem
// section 1
// This creates LibraryBook class that is derived from LibraryItem


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public abstract class LibraryMediaItem : LibraryItem
    {
        public enum MediaType {DVD, BLURAY, VHS, CD, SACD, VINYL}; // enum MediaType is used by Medium 
        public double _duration; // the duration of the media item

        // inherites theTitle, thePublisher, theCopyrightYear, CallNumber, and loan period  from LibraryItem. 
        // has new property: Duration and Medium
        public LibraryMediaItem(String theTitle, String thePublisher,
          int theCopyrightYear, String theCallNumber, int theLoanPeriod, double theDuration, MediaType theMedium) : 
            base(theTitle, thePublisher, theCopyrightYear, theCallNumber, theLoanPeriod)
        {
            Duration = theDuration;
            Medium = theMedium;


        }

        public double Duration
        {
            get
            {
                return _duration;
            }

            // Precondition:  value >= 0
            // Postcondition: The duration has been set to the specified value
            set
            {
                if (value >= 0)
                    _duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} must be >= 0");
            }
        }
         
        public abstract MediaType Medium {get;set;} //creates abstract class Medium that uses MediaType Enum


    
        public abstract override decimal CalcLateFee(int days); //keeps CalcLateFee abstract. not usable at this level


    }
}

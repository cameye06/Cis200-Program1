﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryMusic
// section 1
// This creates LibraryMusic class that is derived from LibraryMediaItem


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class LibraryMusic : LibraryMediaItem
    {
        public int _tracks;
        public string _artist;
        public MediaType _medium;

        // inherites theTitle, thePublisher, theCopyrightYear, theCallNumber, theLoanPeriod, theDuration, theMedium
        // has new property: theArtist, theTracks
        public LibraryMusic
          (String theTitle,
          String thePublisher,
          int theCopyrightYear,
          int theLoanPeriod,
          String theCallNumber,
          double theDuration,
          String theArtist,
          MediaType theMedium,
          int theTracks) : base
                (theTitle,
                thePublisher,
                theCopyrightYear,
                theCallNumber,
                theLoanPeriod,
                theDuration,
                theMedium)
        {
            Artist = theArtist;
            Medium = theMedium;
            NumTracks = theTracks;
        }

        public string Artist
        {
            // Precondition:  None
            // Postcondition: The artist has been returned
            get
            {
                return _artist;
            }

            // Precondition:  None
            // Postcondition: The artist has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Artist)}", value,
                        $"{nameof(Artist)} must not be null or empty");
                else
                    _artist = value;
            }
        }



        public override MediaType Medium
        {
            // Precondition:  None
            // Postcondition: The medium has been returned
            get { return _medium; }
            // Precondition:  is only VHS, DVD, or BluRAy
            // Postcondition: The medium has been set to the specified value 
            set
            {

                if (value == MediaType.VHS || value == MediaType.DVD || value == MediaType.BLURAY) // checks to see if VHS, DVD, or BluRay
                    throw new ArgumentOutOfRangeException($"{nameof(Medium)}", value,
                        $"{nameof(Medium)} of a movie has to be a VHS, DVD, or BluRay");

                _medium = value;
            }
        }



            public int NumTracks
            {
            // Precondition:  None
            // Postcondition: The Number of tracks has been returned
                get
                {
                    return _tracks;
                }

            // Precondition:  value >= 1
            // Postcondition: The Number of tracks has been set to the specified value
                set
                {
                    if (value >= 1)
                        _tracks = value;
                    else
                        throw new ArgumentOutOfRangeException($"{nameof(NumTracks)}", value,
                            $"{nameof(NumTracks)} must be >= 0");
                }
            }

        // Precondition:  a number of days has been entered
        // Postcondition: a calculated fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal rate = (decimal).50;//ammount of money/day

            decimal fee = days * rate; // how much they will have to pay

            if (fee > (decimal)20.00) // if late fee is more that $20 it returns $20
            { fee = (decimal)20.00; }

            return fee; // return fee
        }

        public override string ToString() // sends information formated as a string
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";
            return $"Title: {Title}{NL}" + $"Artist: {Artist}{NL}" + $"Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}" + $"Call Number: {CallNumber}{NL}" + $"Loan Period: {LoanPeriod}{NL}"
                + $"No. of Tracks: {NumTracks}{NL}" + $"Duration: {Duration}{NL}" + $"Media type: {Medium}{NL}" + checkedOutBy + $"{ NL}";

        }


    }
 
}


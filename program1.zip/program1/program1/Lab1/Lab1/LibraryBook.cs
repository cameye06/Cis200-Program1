﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryBook
// section 1
// This creates LibraryBook class that is derived from LibraryItem

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class LibraryBook : LibraryItem
    {

        private string _author;      // The book's author

        // inherites theTitle, thePublisher, theCopyrightYear, CallNumber, and loan period  from LibraryItem. 
        // has new property: Author
        public LibraryBook(String theTitle, String theAuthor, String thePublisher,
            int theCopyrightYear, String theCallNumber, int theLoanPeriod) : base (theTitle, thePublisher,
             theCopyrightYear, theCallNumber, theLoanPeriod)
        {
             Author = theAuthor;
        }

        public string Author
        {
            // Precondition:  None
            // Postcondition: The author has been returned
            get
            {
                return _author;
            }

            // Precondition:  value must not be null or empty
            // Postcondition: The Author has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Author)}", value,
                        $"{nameof(Author)} must not be null or empty");
                else
                    _author = value.Trim();
            }
        }

        // Precondition:  a number of days has been entered
        // Postcondition: a calculated fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal rate = (decimal).25; // the cost per day
            decimal fee = days * rate;
            return fee;
        }

        public override string ToString() // sends information formated as a string
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";
            return $"Title: {Title}{NL}" + $"Author: {Author}{NL}" + $"Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}" + $"Call Number: {CallNumber}{NL}" + $"Loan Period: {LoanPeriod}{NL}"
                + checkedOutBy+$"{ NL}";
        }

    }
}

﻿// Program 1
// by: Z8360
// due: 2/14/2018
// file: LibraryPeriodical
// section 1
// This creates LibraryPeriodical class that is derived from LibraryItem

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public abstract class LibraryPeriodical : LibraryItem
    {
        public int _volume; // the volume of periodical 
        public int _number; // the number of periodical
        // inherites theTitle, thePublisher, theCopyrightYear, CallNumber, and loan period  from LibraryItem. 
        // has new property: volume and number
        public LibraryPeriodical
            (String theTitle, String thePublisher,
          int theCopyrightYear, int theLoanPeriod, String theCallNumber, int theVolume, int theNumber) 
            : base(theTitle, thePublisher, theCopyrightYear, theCallNumber, theLoanPeriod)
        {
            Volume = theVolume;
            Number = theNumber;
        }


        public int Volume
        {
            // Precondition:  None
            // Postcondition: The Volume has been returned
            get
            {
                return _volume;
            }

            // Precondition:  value >= 1
            // Postcondition: The volume has been set to the specified value
            set
            {
                if (value >= 1)
                    _volume = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Volume)}", value,
                        $"{nameof(Volume)} must be >= 0");
            }
        }

        public int Number
        {
            // Precondition:  None
            // Postcondition: The number has been returned
            get
            {
                return _number;
            }

            // Precondition:  value >= 1
            // Postcondition: The number has been set to the specified value
            set
            {
                if (value >= 1)
                    _number = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Number)}", value,
                        $"{nameof(Number)} must be >= 0");
            }
        }


        public override string ToString() // returns information formated as a string
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";
            return $"Title: {Title}{NL}"  + $"Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}" + $"Call Number: {CallNumber}{NL}" + $"Loan Period: {LoanPeriod}{NL}"
                + $"Volume: {Volume}{NL}" + $"Number: {Number}{NL}" + checkedOutBy + $"{ NL}";

        }




        public abstract override decimal CalcLateFee(int days); //keeps CalcLateFee abstract. not usable at this level

    }
}
